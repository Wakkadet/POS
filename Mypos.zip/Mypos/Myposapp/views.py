from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib.auth.decorators import login_required
from .models import Promotion,Employee,Product,Member,Product_order,Bill,History_promotion,Item_in_promotion,List_product
from django.contrib import messages
from localStoragePy import localStoragePy
from datetime import datetime
from django.db import connection
import time
localStorage = localStoragePy('me.jkelol111.mypythonapp', 'json')

def loginForm(request):
    if request.user.is_authenticated:
        return redirect('/product')
    return render(request,'login.html')


def login(request):
    username = request.POST['username']
    password = request.POST['password']
    user = auth.authenticate(username=username,password=password)
    if user is not None :
        auth.login(request,user)
        userlogin = User.objects.get(username=username)
        print(userlogin)
        # em = Employee.objects.get(id_user=userlogin.id)
        localStorage.setItem('username',username )
        # if em.Role == 'Admin':
        #     return redirect('/product')
        # if em.Role == 'Finance':
        #     return redirect('/finance')
        # if em.Role == 'Cashier':
        #     return redirect('/cashier')
        return redirect('/product')
    else:
        print('FFFFFFFFFFF')
        messages.info(request,'password not correct!!')
        return redirect('/login_error')

@login_required
def Register(request):
    if request.method == 'POST':
        alldata = request.POST
        print(alldata['Firstname'])
        if alldata["password"] == alldata["repassword"]:
            if User.objects.filter(username=alldata["username"]).exists():
                print('Username มีคนใช้เเล้ว')
                return render(request,'Add_employee.html')
            else:
                user = User.objects.create_user(username=alldata["username"],password=alldata["password"])
                user.save()
                datauser = User.objects.get(username=alldata["username"])
                print("-------------------------------------------------------------------------------------------s")
                addEmployee = Employee(id_user=datauser.id,Role=alldata['Role'],IDcard = alldata['IDcard'],
                Title_Name = alldata['Title_Name'],Firstname = alldata['Firstname'],Lastname=alldata['Lastname'],Age=alldata['Age'],Gender=alldata['Gender'],
                Email=alldata['email'],Phonenumber=alldata['Phonenumber'],Blood_Type=alldata['bloodtype'],Birthday=alldata['Birthday'],Ethnicity=alldata['Ethnicity'],
                Nationality=alldata['Nationality'],Religion=alldata['Religion'],Address=alldata['Address'],Maritial_Status=alldata['Maritial_Status'],Education_Level=alldata['Education_Level'],
                Emergency_Tel=alldata['Emergency_Tel'],Relationship=alldata['Relationship'],Father_Name=alldata['FatherFirstname'],Father_Lastname=alldata['FatherLastname'],
                Father_Career=alldata['FatherCareer'],Father_Tel=alldata['FatherPhonenumber'],Father_Ethnicty=alldata['FatherEthnicity'],Father_Nationallity=alldata['FatherNationality'],
                Father_Religion=alldata['FatherReligion'],Father_Address=alldata['FatherAddress'],Mother_Title=alldata['Mother_Title'],Mother_Name=alldata['MotherFirstname'],Mother_Lastname=alldata['MotherLastname'],
                Mother_Career=alldata.get('MotherCareer'),Mother_Tel=alldata['MotherPhonenumber'],Mother_Ethnicty=alldata['MotherEthnicity'],Mother_Nationallity=alldata['MotherNationality'],
                Mother_Religion=alldata['MotherReligion'],Mother_Address=alldata['MotherAddress'],status=1)	
                addEmployee.save()
                # IDcard	Title_Name	Firstname	Lastname	Age	Gender	Email	Phonenumber	Blood_Type	Birthday	Ethinity	Nationality	Religion	
                # Address	Maritial_Status	Education_Level	Emergency_Tel	Relationship	Father_Title	Father_Name	Father_Lastname	Career	Father_Tel	Father_Ethnicty	Father_Nationallity	Father_Religion	
                # Father_Address	Mother_Title	Mother_Name	Mother_Lastname	Mother_Career	Mother_Tel	Mother_Ethnicty	Mother_Religion	Mother_Address	Mother_Nationallity	Role	id_user_id	 )
                time.sleep(1)
                return redirect('/employee/')

        else:
            return render(request,'Add_employee.html')

    return render(request,'Add_employee.html')


def login_error(request):
    return render(request,'login_error.html')

@login_required
def product(request):
    title = "Product"
    data = Product.objects.all()
    return render(request,'product.html',{"title":title,"data":data})

@login_required
def Tax_report(request):
    data = Product.objects.all()
    return render(request,'Tax_report.html',{"data":data})

@login_required
def search_product(request):
    title = "Product"
    alldata = Product.objects.all()
    data = []
    Barcode = request.GET.get("Barcode")
    for i in alldata:
        print(i.id)
        if str(i.Barcode_ID) == str(Barcode):
            data.append(i)
    return render(request,'product.html',{"title":title, "data":data})

@login_required
def del_Product(request,pk):
    item = Product.objects.get(id=pk)
    item.status = 0
    item.save()
    return redirect('/product/')
    
@login_required
def add_Product(request):
    if request.method == 'POST':
        alldata = request.POST
        add = Product()
        add.Barcode_ID = alldata['Barcode']
        if Product.objects.filter(Barcode_ID=alldata["Barcode"]).exists():
            print('Barcode ใช้เเล้ว')
            return render(request,'add_product.html')
        add.Name = alldata['name']
        add.Size = alldata['inlineRadioOptions']
        add.Color = alldata['color']
        add.Type = alldata['type']
        add.Model = alldata['model']
        add.Cost = alldata['cost']
        add.Price = alldata['price']
        add.VAT = alldata['vat1']
        add.Excluding_VAT = alldata['ex-vat1'] 
        add.id_Promotion = 0
        add.status = 1
        add.save()
        return redirect('/product/')
    return render(request,'add_product.html',{"a":False})

def edit_Product(request , pk):
    title = 'Edit Product'
    item = Product.objects.get(id=pk)
    if request.method =='POST':
        alldata = request.POST
        add = Product.objects.get(id=pk)
        add.Barcode_ID = alldata['Barcode'] 
        add.Name = alldata['name']
        add.Size = alldata['inlineRadioOptions']
        add.Color = alldata['color']
        add.Type = alldata['type']
        add.Model = alldata['model']
        add.Cost = alldata['cost']
        add.Price = alldata['price']
        add.VAT = alldata['vat1']
        add.Excluding_VAT = alldata['ex-vat1'] 
        add.save()
        return redirect('product')
    return render(request,'edit_product.html',{'a':True,'item':item,'pk':pk})
# -----------------------------------------------------promotion-------------------------------------------------------------------------    
@login_required
def promotion(request):
    title = 'Promotion'
    data = Promotion.objects.all()
    timecurrent = datetime.today().strftime('%Y-%m-%d')
    print(timecurrent)
    change = 0
    for i in data:
        print(i.end_date,timecurrent)
        if str(i.end_date) <= str(timecurrent):
            print(i.id)
            history = History_promotion(name = i.name , types= i.types ,start_date= i.start_date ,
                        end_date=i.end_date ,
                        apply=i.apply,value = i.value , by= i.by
                        )
            history.save()
            his = History_promotion.objects.get(name=i.name)
            for j in List_product.objects.filter(id_promotion =i.id):
                product =  Product.objects.get(id = j.id_product)
                item = Item_in_promotion(id_history=his.id,Barcode_ID = product.Barcode_ID , Name= product.Name,Size= product.Size,Color= product.Color,
                        Type= product.Type,Model= product.Model,Cost= product.Cost,Price= product.Price,
                        VAT= product.VAT,Excluding_VAT= product.Excluding_VAT)
                item.save()
                j.delete()

            Promotion.objects.filter(id=i.id).delete()
            print('overtime promotion')
            change = 1
    if change == 1:
        data = Promotion.objects.all()
    return render(request,'promotion.html',{"title":title,"data":data})

@login_required
def promotion_view(request,pk):
    title = 'Promotion' 
    item = Promotion.objects.get(id=pk)
    # listpd = List_product.objects.filter(id_promotion=pk)
    # print(listpd)
    # item2 = list(item)
    # ------------------fetch item in table--------------------retern เเค่ของตัวเอง
    cursor = connection.cursor()
    cursor.execute('select * from myposapp_list_product join myposapp_product on myposapp_list_product.id_product = myposapp_product.id WHERE myposapp_list_product.id_promotion = '+pk+'')
    data = cursor.fetchall()
    print(data,'==============================================')
    # -----------------------------------------------------------
    print(item.start_date)
    if item.types == 'Percent off':
        return render(request,'promotion_discount.html',{"title":title,"item":item,"c":"1","data":data})
    elif item.types == 'Amount off':
        return render(request,'promotion_discount.html',{"title":title,"item":item,"c":"1","data":data})
    elif item.types == 'Buy X Get Y':
        cursor3 = connection.cursor()
        cursor2 = connection.cursor()
        cursor3.execute('select * from myposapp_list_product join myposapp_product on myposapp_list_product.id_product = myposapp_product.id WHERE myposapp_list_product.id_promotion = '+pk+' AND myposapp_list_product.Xory = "X" ')
        cursor2.execute('select * from myposapp_list_product join myposapp_product on myposapp_list_product.id_product = myposapp_product.id WHERE myposapp_list_product.id_promotion = '+pk+' AND myposapp_list_product.Xory = "y" ')
        data = cursor3.fetchall()
        data2 = cursor2.fetchall()
        return render(request,'promotion_buyXGetY.html',{"title":title,"item":item,"c":"1","data":data,"data2":data2})
    elif item.types == 'Combo Set':
        return render(request,'promotion_comboset.html',{"title":title,"item":item,"c":"1","data":data})
    elif item.types == 'At least':
        return render(request,'promotion_atlest.html',{"title":title,"item":item,"c":"1"})
    return redirect('/promotion')

@login_required
def delete_promotion(request,pk):
    item = Promotion.objects.get(id=pk)
    history = History_promotion(name = item.name , types= item.types ,start_date= item.start_date ,
                        end_date=item.end_date ,
                        apply=item.apply,value = item.value , by= item.by
                        )
    history.save()
    his = History_promotion.objects.get(name=item.name)
    for j in List_product.objects.filter(id_promotion = pk):
        product =  Product.objects.get(id = j.id_product)
        item1 = Item_in_promotion(id_history=his.id,Barcode_ID = product.Barcode_ID , Name= product.Name,Size= product.Size,Color= product.Color,
                Type= product.Type,Model= product.Model,Cost= product.Cost,Price= product.Price,
                VAT= product.VAT,Excluding_VAT= product.Excluding_VAT)
        item1.save()
        j.delete()

    print(item1.id)
    item.delete()
    return redirect('/promotion')

@login_required
def deleteitem_promotion(request,pk):
    checktype = localStorage.getItem('checktype')
    item = List_product.objects.get(id=pk)
    print(item.id)
    item.delete()
    if  checktype == 'discount':
        return redirect("/promotion/discount")
    if  checktype == 'Buy X Get Y':
        return redirect("/promotion/buyXGetY")
    else:
        return redirect("/promotion/comboset")

@login_required
def additem_promotion(request):                                     
    title = 'Promotion'
    if request.method == 'POST':
        checktype = localStorage.getItem('checktype')
        if request.POST['barcodeID']  is not None or request.POST['barcodeID'] != "" :
            try:
                
                Product.objects.get(Barcode_ID=request.POST['barcodeID'])

                if checktype == 'Buy X Get Y':
                    print('1')
                    try :
                        item = List_product.objects.filter(id_product = int(Product.objects.get(Barcode_ID=request.POST['barcodeID']).id), id_promotion = -1 , Xory=request.POST['xy'] )
                        print(item[0])
                        print('Promotion มีเเล้ว')
                        localStorage.setItem('error','product has been use.')
                        
                    except Exception as e:
                        print(e)
                        item = List_product(id_product=Product.objects.get(Barcode_ID=request.POST['barcodeID']).id,id_promotion = -1,Xory=request.POST['xy'] )
                        item.save()
                       
                    return redirect("/promotion/buyXGetY")
                    
                if checktype == 'discount':
                    print('3')
                    try :
                        item = List_product.objects.filter(id_product=Product.objects.get(Barcode_ID= int(request.POST['barcodeID'])).id, id_promotion = 0 , Xory='a'  )
                        print(Product.objects.get(Barcode_ID=request.POST['barcodeID']).id)
                        print(item[0])
                        print('Promotion มีเเล้วasdasdasdsad')
                        localStorage.setItem('error','product has been use.')
                    except Exception as e:
                        print(e)
                        item = List_product(id_product=Product.objects.get(Barcode_ID=request.POST['barcodeID']).id,id_promotion =0 , Xory='a'  )
                        item.save()
                        
                    return redirect("/promotion/discount")
                if checktype == 'Combo Set':
                    print('3')
                    try :
                        item = List_product.objects.filter(id_product=Product.objects.get(Barcode_ID=request.POST['barcodeID']).id,id_promotion =-2 , Xory='a' )
                        print(item[0])
                        print('Promotion มีเเล้ว')
                        localStorage.setItem('error','product has been use.') 

                    except Exception as e:
                        print(e)
                        item = List_product(id_product=Product.objects.get(Barcode_ID=request.POST['barcodeID']).id,id_promotion =-2 , Xory='a')
                        item.save()
                    return redirect("/promotion/comboset")
                        
            except Exception as e:
                print('44444')
                print(e)
                
                localStorage.setItem('error','Product not found.')
                if checktype == 'Buy X Get Y':
                    return redirect("/promotion/buyXGetY")
                if   checktype == 'discount':
                    return redirect("/promotion/discount")
                else :
                    return redirect("/promotion/comboset")
    
    print('22222222')
    return redirect("/promotion")
# --------------------------------0---------------โปรเดียวห้ามไอเทมซ้ำ
@login_required
def promotion_discount(request):
    title = 'Promotion'
    localStorage.setItem('checktype','discount')
    username = localStorage.getItem('username')
    # ------------------fetch item in table--------------------
    cursor = connection.cursor()
    cursor.execute('select * from myposapp_list_product join myposapp_product on myposapp_list_product.id_product = myposapp_product.id WHERE myposapp_list_product.id_promotion = 0')
    data = cursor.fetchall()
    # -----------------------------------------------------------
    if request.method == 'POST':
        alldata = request.POST
        if Promotion.objects.filter(name=alldata['promotion_name']).exists():
            print('Promotion มีเเล้ว')
            localStorage.setItem('name_error','name has been use.')
        else:
            item = Promotion(name = alldata['promotion_name'] , types=alldata["type"] ,start_date=alldata['startdate'] ,
                            end_date=alldata['enddate'] ,
                            apply=alldata['select'],value = alldata['discount_value'] , by=username
                            )
            item.save()
            promotion.id = Promotion.objects.get(name=alldata['promotion_name']).id
            product = Product.objects.all()
            List_product.objects.filter(id_promotion=0).update(id_promotion=promotion.id)
            for i in List_product.objects.filter(id_promotion=promotion.id):
                product = Product.objects.get(id=i.id_product)
                product.id_Promotion = promotion.id
                product.save()
            localStorage.setItem('checktype','')
            return redirect('/promotion')
    # data = Promotion.objects.all()
    error = localStorage.getItem('error')
    print(error)
    localStorage.setItem('error',"")
    name_error = localStorage.getItem('name_error')
    print(name_error)
    localStorage.setItem('name_error',"")
    return render(request,'promotion_discount.html',{"title":title,'data':data,'error':error,'name_error':name_error})
    # -------------------------------1------------------------
@login_required
def promotion_buyXGetY(request):
    title = 'Promotion'
    localStorage.setItem('checktype','Buy X Get Y')
    username = localStorage.getItem('username')
     # ------------------fetch item in table--------------------
    cursor = connection.cursor()
    cursor2 = connection.cursor()
    cursor.execute('select * from myposapp_list_product join myposapp_product on myposapp_list_product.id_product = myposapp_product.id WHERE myposapp_list_product.id_promotion = -1 AND myposapp_list_product.Xory = "X" ')
    cursor2.execute('select * from myposapp_list_product join myposapp_product on myposapp_list_product.id_product = myposapp_product.id WHERE myposapp_list_product.id_promotion = -1 AND myposapp_list_product.Xory = "y" ')
    data = cursor.fetchall()
    data2 = cursor2.fetchall()
    # -----------------------------------------------------------
    if request.method == 'POST':
        alldata = request.POST
        if Promotion.objects.filter(name=alldata['promotion_name']).exists():
            print('Promotion มีเเล้ว')
            localStorage.setItem('name_error','name has been use.')
        else:
            item = Promotion(name = alldata['promotion_name'] , types='Buy X Get Y' ,start_date=alldata['startdate'] ,
                            end_date=alldata['enddate'] ,
                            value = 0,by=username
                            )
            item.save()
            promotion.id = Promotion.objects.get(name=alldata['promotion_name']).id
            product = Product.objects.all()
            List_product.objects.filter(id_promotion=-1).update(id_promotion=promotion.id)
            for i in List_product.objects.filter(id_promotion=promotion.id):
                product = Product.objects.get(id=i.id_product)
                product.id_Promotion = promotion.id
                product.save()
            localStorage.setItem('checktype','')
            return redirect('/promotion')

    error = localStorage.getItem('error')
    print(error)
    localStorage.setItem('error',"")
    name_error = localStorage.getItem('name_error')
    print(name_error)
    localStorage.setItem('name_error',"")
    return render(request,'promotion_buyXGetY.html',{"title":title,'data':data,'data2':data2,'error':error,'name_error':name_error})
# ---------------------------------------2------------------------
@login_required
def promotion_comboset(request):
    title = 'Promotion'
    localStorage.setItem('checktype','Combo Set')
    username = localStorage.getItem('username')
     # ------------------fetch item in table--------------------
    cursor = connection.cursor()
    cursor.execute('select * from myposapp_list_product join myposapp_product on myposapp_list_product.id_product = myposapp_product.id WHERE myposapp_list_product.id_promotion = -2')
    data = cursor.fetchall()
    # -----------------------------------------------------------
    if request.method == 'POST':
        alldata = request.POST
        if Promotion.objects.filter(name=alldata['promotion_name']).exists():
            print('Promotion มีเเล้ว')
            localStorage.setItem('name_error','name has been use.')
        else:
            item = Promotion(name = alldata['promotion_name'] , types='Combo Set',start_date=alldata['startdate'] ,
                            end_date=alldata['enddate'] ,
                            value = alldata['discount_value'] ,by=username
                            )
            item.save()
            promotion.id = Promotion.objects.get(name=alldata['promotion_name']).id
            product = Product.objects.all()
            List_product.objects.filter(id_promotion=-2).update(id_promotion=promotion.id)
            print(List_product.objects.filter(id_promotion=-2).update(id_promotion=promotion.id),'*************************')
            for i in List_product.objects.filter(id_promotion=promotion.id):
                product = Product.objects.get(id=i.id_product)
                product.id_Promotion = promotion.id
                product.save()
            localStorage.setItem('checktype','')
            return redirect('/promotion')

    error = localStorage.getItem('error')
    print(error)
    localStorage.setItem('error',"") 
    name_error = localStorage.getItem('name_error')
    print(name_error)
    localStorage.setItem('name_error',"")   
    return render(request,'promotion_comboset.html',{"title":title,'data':data,'error':error,'name_error':name_error})

@login_required
def promotion_atlest(request):
    title = 'Promotion'
    username = localStorage.getItem('username')
    if request.method == 'POST':
        alldata = request.POST
        if Promotion.objects.filter(name=alldata['promotion_name']).exists():
            print('Promotion มีเเล้ว')
            localStorage.setItem('name_error','name has been use.')
        else:
            item = Promotion(name = alldata['promotion_name'] , types=alldata["type"] ,start_date=alldata['startdate'] ,
                            end_date=alldata['enddate'] ,
                            atlest = alldata['atlest'] , value= alldata['discount_value'], by=username
                            )
            item.save()
            return redirect('/promotion')

    name_error = localStorage.getItem('name_error')
    print(name_error)
    localStorage.setItem('name_error',"")
    return render(request,'promotion_atlest.html',{"title":title,'name_error':name_error})



@login_required
def history_promotion(request):
    title = 'History Promotion'
    data = History_promotion.objects.all()
    return render(request,'history_promotion.html',{"title":title,'data':data})

@login_required
def history_view(request,pk):
    title = 'Promotion' 
    try:
        item = History_promotion.objects.get(id=pk)
        data = Item_in_promotion.objects.filter(id_history=pk)
        print(data[0].id)
        if item.types == 'Percent off':
            return render(request,'promotion_discount.html',{"title":title,"item":item,"data":data,"c":"1",})
        elif item.types == 'Amount off':
            return render(request,'promotion_discount.html',{"title":title,"item":item,"data":data,"c":"1"})
        elif item.types == 'Buy X Get Y':
            return render(request,'promotion_buyXGetY.html',{"title":title,"item":item,"data":data,"c":"1"})
        elif item.types == 'Combo Set':
            return render(request,'promotion_comboset.html',{"title":title,"item":item,"data":data,"c":"1"})
        elif item.types == 'At least':
            return render(request,'promotion_atlest.html',{"title":title,"item":item,"data":data,"c":"1"})
    except Exception as e:
        print(e)
        if item.types == 'Percent off':
            return render(request,'promotion_discount.html',{"title":title,"item":item,"c":"1"})
        elif item.types == 'Amount off':
            return render(request,'promotion_discount.html',{"title":title,"item":item,"c":"1"})
        elif item.types == 'Buy X Get Y':
            return render(request,'promotion_buyXGetY.html',{"title":title,"item":item,"c":"1"})
        elif item.types == 'Combo Set':
            return render(request,'promotion_comboset.html',{"title":title,"item":item,"c":"1"})
        elif item.types == 'At least':
            return render(request,'promotion_atlest.html',{"title":title,"item":item,"c":"1"})
# --------------------------------------------------------------------------------------------------------------------------
@login_required
def Membership_promotion(request):
    return render(request,'promotion_member.html')

@login_required
def Membership_promotion_discount(request):
    return render(request,'promotion_member_discount.html')

@login_required
def Membership_promotion_discount2(request):
    return render(request,'promotion_member_discount2.html')

@login_required
def employee(request):
    title = 'Employee'
    data = Employee.objects.all()
    return render(request,'employee.html',{"title":title,'data':data})

@login_required
def AddEmployee(request):
    title = 'Employee'
    return render(request,'Add_employee.html',{"title":title})

@login_required
def edit_employee(request,pk):
    title = 'Edit Employee'
    data = Employee.objects.get(id=pk)
    if request.method == 'POST':
        alldata = request.POST
        datauser = User.objects.get(id=data.id_user)
        
        add = Employee.objects.get(id=pk)
       
        add.IDcard = alldata['IDcard']
        add.Title_Name = alldata['Title_Name']
        add.Firstname = alldata['Firstname']
        add.Lastname=alldata['Lastname']
        add.Age=alldata['Age']
        add.Gender=alldata['Gender']
        add.Email=alldata['email']
        add.Phonenumber=alldata['Phonenumber']
        add.Blood_Type=alldata['bloodtype']
        add.Birthday=alldata['Birthday']
        add.Ethnicity=alldata['Ethnicity']
        add.Nationality=alldata['Nationality']
        add.Religion=alldata['Religion']
        add.Address=alldata['Address']
        add.Maritial_Status=alldata['Maritial_Status']
        add.Education_Level=alldata['Education_Level']
        add.Emergency_Tel=alldata['Emergency_Tel']
        add.Relationship=alldata['Relationship']
        add.Father_Name=alldata['FatherFirstname']
        add.Father_Lastname=alldata['FatherLastname']
        add.Father_Career=alldata['FatherCareer']
        add.Father_Tel=alldata['FatherPhonenumber']
        add.Father_Ethnicty=alldata['FatherEthnicity']
        add.Father_Nationallity=alldata['FatherNationality']
        add.Father_Religion=alldata['FatherReligion']
        add.Father_Address=alldata['FatherAddress']
        add.Mother_Title=alldata['Mother_Title']
        add.Mother_Name=alldata['MotherFirstname']
        add.Mother_Lastname=alldata['MotherLastname']
        add.Mother_Career=alldata.get('MotherCareer')
        add.Mother_Tel=alldata['MotherPhonenumber']
        add.Mother_Ethnicty=alldata['MotherEthnicity']
        add.Mother_Nationallity=alldata['MotherNationality']
        add.Mother_Religion=alldata['MotherReligion']
        add.Mother_Address=alldata['MotherAddress']
        add.save()
        return redirect('/employee')
    return render(request,'Edit_employee.html',{'data':data,'pk':pk})

@login_required
def Search_Employee(request):
    title = 'Employee'
    alldata = Employee.objects.all()
    data = []
    SearchBar = request.GET.get("Searchbar")
    for i in alldata:
        if str(i.id) == str(SearchBar):
            data.append(i)
    return render(request,'employee.html',{"title":title, "data":data})

@login_required
def del_employee(request,pk):
    item = Employee.objects.get(id=pk)
    item.status = 0
    item.save()
    return redirect('/employee/')


@login_required
def Membership(request):
    title = 'Member'
    data = Member.objects.all()
    return render(request,'Member.html',{"title":title,"data":data})

@login_required
def Search_Membership(request):
    title = 'Member'
    alldata = Member.objects.all()
    data = []
    search = request.GET.get("search")
    for i in alldata:
        if str(i.Phonenumber) == str(search):
            data.append(i)
    return render(request,'Member.html',{"title":title, "data":data})
@login_required
def del_Membership(request,pk):
    item = Member.objects.get(Member_ID=pk)
    item.status = 0
    item.save()
    return redirect('/membership/')

@login_required
def add_Membership(request):
    print("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
    title = 'Add Membership'
    if request.method == 'POST':
        alldata = request.POST
        if Member.objects.filter(Phonenumber=alldata["Phonenumber"]).exists():
            print('เบอร์มีคนใช้เเล้ว')
            return render(request,'AddMember1.html')
        else:
            add = Member()
            try :
                last_mem = Member.objects.all().last()
                last  = last_mem.Member_ID
                last += 1 

            except :
                last = 1

            add.Member_ID = last
            add.IDcard= request.POST['IDcard']
            add.Title_Name= request.POST['title_name']
            add.Firstname=request.POST['name']
            add.Lastname=request.POST['Lastname']
            add.Gender=request.POST['Gender']
            add.Age=request.POST['Age']
            add.Email=request.POST['Email']
            add.Phonenumber=request.POST['Phonenumber']
            add.Birthday=request.POST['Birthday']
            add.Address=request.POST['Address']
            add.Point= 0
            add.status = 1

            add.save()
        return redirect('/membership')
    return render(request,'AddMember1.html')

@login_required
def edit_Membership(request,pk):
    title = 'Edit Membership'
    data = Member.objects.get(Member_ID=pk)
    if request.method == 'POST':
        alldata = request.POST
      
        add = Member.objects.get(Member_ID=pk)
        add.IDcard= alldata['IDcard']
        add.Title_Name= alldata['title_name']
        add.Firstname=alldata['name']
        add.Lastname=alldata['Lastname']
        add.Gender=alldata['Gender']
        add.Age=alldata['Age']
        add.Email=alldata['Email']
        add.Phonenumber=alldata['Phonenumber']
        add.Birthday=alldata['Birthday']
        add.Address=alldata['Address']
        add.save()
        return redirect('/membership')
    return render(request,'Edit_member.html',{'data':data,'pk':pk})

@login_required
def Sales_report(request):
    return render(request,'layout_admin.html')

@login_required
def Bill_info(request,pk):
    item = Bill.objects.get(id=pk)
    change = item.Receive - item.Total
    sub = item.Total + item.Discount
    return render(request,'Bill_info.html',{'item':item , "change":change , "sub":sub})


@login_required
def Daily_report(request):
    return render(request,'DailyReport.html')

@login_required
def Sales_history(request):
    title = 'Sale History'
    data = Bill.objects.all()
    # date_Start = request.GET.get("date_start")
    # date_Stop = request.GET.get("date_stop")
    # if(date_Stop>date_Start):
    #     print("PASS")
    # print(date_Start)
    # print(date_Stop)
    return render(request,'Sale_history.html',{"title":title,"data":data})   

@login_required
def Check_history_Date(request):
    title = 'Sale History'
    alldata = Bill.objects.all()
    data = []
    ID = request.GET.get("ID")
    date_Start = request.GET.get("date_start")
    date_Stop = request.GET.get("date_stop")
    for i in alldata:
        if str(i.Date) >= date_Start and str(i.Date)<=date_Stop:
            data.append(i)
    return render(request,'Sale_history.html',{"title":title, "data":data})   

def Check_history_ID(request):
    title = 'Sale History'
    alldata = Bill.objects.all()
    data = []
    ID = request.GET.get("ID")
    print(ID)
    for i in alldata:
        print(i.id)
        if str(i.id) == str(ID):
            data.append(i)
    return render(request,'Sale_history.html',{"title":title, "data":data})
@login_required
def Document(request):
    title = 'Document'
    data = Bill.objects.all()
    return render(request,'Document.html',{"title":title,"data":data}) 
@login_required
def Document_Date(request):
    title = 'Document'
    alldata = Bill.objects.all()
    data = []
    date_Start = request.GET.get("date_start")
    date_Stop = request.GET.get("date_stop")
    for i in alldata:
        if str(i.Date) >= date_Start and str(i.Date)<=date_Stop:
            data.append(i)
    return render(request,'Document.html',{"title":title, "data":data})

@login_required
def finance_mode(request):
    return render(request,'layout_finance.html')


@login_required
def Cashier_mode(request):
    username = localStorage.getItem('username')
    userlogin = User.objects.get(username=username)
    em = Employee.objects.get(id_user=userlogin.id)
    
    if request.GET.get('phonemember')  is None or request.GET.get('phonemember') == "" :
        if em.Role == 'Admin':
            #member = Member.objects.get(Phonenumber=)
            #print(member)
            member = ""
            if request.GET.get('barcodeID') :
                barcode = request.GET.get('barcodeID')
             
                
                product_or =  Product_order()
                product_or.Product_id = Product.objects.get(Barcode_ID=barcode).id
                product_or.Bill_id = 1
                product_or.Employee_id = Employee.objects.get(Firstname=localStorage.getItem('username')).id_user
                product_or.Quantity = int(request.GET.get('input_price'))
                product_or.Unit_price = Product.objects.get(Barcode_ID=barcode).Price
                product_or.save()
            return render(request,'cashier_admin.html',{'member':member})
        if em.Role == 'Cashier':
            return render(request,'cashier.html')
    else :
        phone = request.GET.get('phonemember')
        try :
            member = Member.objects.get(Phonenumber=phone)
            if request.GET.get('barcodeID') :
                barcode = request.GET.get('barcodeID')
                barcode = Product.objects.get(Barcode_ID = barcode)
                
                product_or =  Product_order()
                product_or.Product_id = Product.objects.get(Barcode_ID=barcode).id
                product_or.Bill_id = 1
                product_or.Employee_id = Employee.objects.get(Firstname=localStorage.getItem('username')).id_user
                product_or.Quantity = request.GET.get('input_price')
                product_or.Unit_price = Product.objects.get(Barcode_ID=barcode).Price
                product_or.save()
                
            
            
            return render(request,'cashier_admin.html',{'member':member})
        except :
            member = ""
            
            return render(request,'cashier_admin.html',{'member':member})  
        
        
    
       
    return redirect('/login')


@login_required
def Cashier_success(request):
    return render(request,'cashier_success.html')

@login_required
def Logout(request):
    auth.logout(request)
    localStorage.clear()
    print('logout eiei')
    return redirect('/') 